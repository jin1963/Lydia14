# LYDIA Foundation
This project hosts the frontend for staking, vesting, and DAO voting.